more -d ./general_instructions.txt;
more -d ./src/master/master.txt;
more -d ./src/command/command.txt;
more -d ./src/motor_x/motor_x.txt;
more -d ./src/motor_z/motor_z.txt;
more -d ./src/inspection/inspection.txt;
more -d ./src/watchdog/watchdog.txt;

