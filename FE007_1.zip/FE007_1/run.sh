#Master process will be executed in the "executables" directory
(cd src/executables; ./master);